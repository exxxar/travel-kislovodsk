<?php

namespace App\Core;

abstract class RolesEnum
{
    const Admin = 1;
    const User = 2;
}
