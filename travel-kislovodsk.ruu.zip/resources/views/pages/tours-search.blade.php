@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <tour-search-page></tour-search-page>
    <footer-component></footer-component>
@endsection
