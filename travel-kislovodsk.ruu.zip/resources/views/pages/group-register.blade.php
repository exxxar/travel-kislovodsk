@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <group-register-page></group-register-page>
    <footer-component></footer-component>
@endsection
