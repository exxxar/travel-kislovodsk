@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component class="position-absolute dt-page-header--bg-none-image"></header-component>
    <guide-page></guide-page>
    <footer-component></footer-component>
@endsection
