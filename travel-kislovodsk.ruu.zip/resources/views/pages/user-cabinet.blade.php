@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <user-cabinet-page></user-cabinet-page>
    <footer-component></footer-component>
@endsection
