@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <tours-hot-page></tour-page>
    <footer-component></footer-component>
@endsection
