@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <favorites-page></favorites-page>
    <footer-component></footer-component>
@endsection
