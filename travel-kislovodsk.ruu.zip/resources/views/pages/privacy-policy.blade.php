@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <privacy-policy-page></privacy-policy-page>
    <footer-component></footer-component>
@endsection
