@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <about-page></about-page>
    <benefits-component></benefits-component>
    <footer-component></footer-component>
@endsection
