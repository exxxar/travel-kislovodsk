
@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <login-page></login-page>
    <footer-component></footer-component>
@endsection
