
@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <registration-page></registration-page>
    <footer-component></footer-component>
@endsection
