
@extends("layouts.app")

@section("content")
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>

    Страница сброса пароля
    <footer-component></footer-component>
@endsection
