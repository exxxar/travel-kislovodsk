import AppListing from '../app-components/Listing/AppListing';

Vue.component('tourist-member-listing', {
    mixins: [AppListing]
});