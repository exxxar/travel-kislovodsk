import AppListing from '../app-components/Listing/AppListing';

Vue.component('schedule-listing', {
    mixins: [AppListing]
});