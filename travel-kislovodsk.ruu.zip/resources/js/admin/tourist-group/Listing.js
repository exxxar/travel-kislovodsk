import AppListing from '../app-components/Listing/AppListing';

Vue.component('tourist-group-listing', {
    mixins: [AppListing]
});