import AppListing from '../app-components/Listing/AppListing';

Vue.component('tour-object-listing', {
    mixins: [AppListing]
});