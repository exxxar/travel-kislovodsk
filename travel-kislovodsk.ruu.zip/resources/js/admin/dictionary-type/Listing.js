import AppListing from '../app-components/Listing/AppListing';

Vue.component('dictionary-type-listing', {
    mixins: [AppListing]
});