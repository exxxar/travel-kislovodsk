import AppListing from '../app-components/Listing/AppListing';

Vue.component('review-listing', {
    mixins: [AppListing]
});