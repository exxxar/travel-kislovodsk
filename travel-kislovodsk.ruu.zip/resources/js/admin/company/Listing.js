import AppListing from '../app-components/Listing/AppListing';

Vue.component('company-listing', {
    mixins: [AppListing]
});