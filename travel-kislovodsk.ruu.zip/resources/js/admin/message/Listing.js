import AppListing from '../app-components/Listing/AppListing';

Vue.component('message-listing', {
    mixins: [AppListing]
});