import AppListing from '../app-components/Listing/AppListing';

Vue.component('transaction-listing', {
    mixins: [AppListing]
});