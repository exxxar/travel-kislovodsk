import AppListing from '../app-components/Listing/AppListing';

Vue.component('tourist-guide-listing', {
    mixins: [AppListing]
});