import AppListing from '../app-components/Listing/AppListing';

Vue.component('favorite-listing', {
    mixins: [AppListing]
});