import AppListing from '../app-components/Listing/AppListing';

Vue.component('dictionary-listing', {
    mixins: [AppListing]
});