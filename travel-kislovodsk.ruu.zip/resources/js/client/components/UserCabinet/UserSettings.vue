<template>
    <form class="personal-account__content">
        <h2 class="personal-account__title personal-account__title_black fw-bold">
            Настройка профиля
        </h2>
        <div class="personal-account-input__grid_three">
            <div class="personal-account-input__container">
                <div class="dt-input__wrapper">
                    <div class="d-flex align-items-center justify-content-between"><label
                        class="dt-input__label">фамилия</label>
                    </div>
                    <div class="dt-input__group bg-white">
                        <input type="text" placeholder="Иванов" class="dt-input"
                               autocomplete="off" maxlength="255">
                        <div class="dt-input__group-item">
                            <div class="dt-input__icon">
                                <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%"
                                     viewBox="0 0 48 48" fill="#0071eb">
                                    <path
                                        d="M24 23.8q-3.45 0-5.625-2.175T16.2 16q0-3.45 2.175-5.625T24 8.2q3.45 0 5.625 2.175T31.8 16q0 3.45-2.175 5.625T24 23.8ZM7.7 40.45v-5q0-2 1-3.425 1-1.425 2.55-2.175 3.4-1.5 6.5-2.25t6.25-.75q3.15 0 6.225.775Q33.3 28.4 36.7 29.9q1.6.7 2.6 2.125t1 3.425v5Zm3.4-3.4h25.8V35.5q0-.8-.475-1.525-.475-.725-1.175-1.075-3.15-1.5-5.775-2.075Q26.85 30.25 24 30.25q-2.85 0-5.525.575Q15.8 31.4 12.7 32.9q-.7.35-1.15 1.075-.45.725-.45 1.525ZM24 20.4q1.9 0 3.15-1.25T28.4 16q0-1.9-1.25-3.15T24 11.6q-1.9 0-3.15 1.25T19.6 16q0 1.9 1.25 3.15T24 20.4Zm0-4.4Zm0 21.05Z"/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="personal-account-input__container">
                <div class="dt-input__wrapper">
                    <div class="d-flex align-items-center justify-content-between"><label
                        class="dt-input__label">имя</label>
                    </div>
                    <div class="dt-input__group bg-white">
                        <input type="text" placeholder="Николай" class="dt-input"
                               autocomplete="off" maxlength="255">
                        <div class="dt-input__group-item">
                            <div class="dt-input__icon">
                                <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%"
                                     viewBox="0 0 48 48" fill="#0071eb">
                                    <path
                                        d="M24 23.8q-3.45 0-5.625-2.175T16.2 16q0-3.45 2.175-5.625T24 8.2q3.45 0 5.625 2.175T31.8 16q0 3.45-2.175 5.625T24 23.8ZM7.7 40.45v-5q0-2 1-3.425 1-1.425 2.55-2.175 3.4-1.5 6.5-2.25t6.25-.75q3.15 0 6.225.775Q33.3 28.4 36.7 29.9q1.6.7 2.6 2.125t1 3.425v5Zm3.4-3.4h25.8V35.5q0-.8-.475-1.525-.475-.725-1.175-1.075-3.15-1.5-5.775-2.075Q26.85 30.25 24 30.25q-2.85 0-5.525.575Q15.8 31.4 12.7 32.9q-.7.35-1.15 1.075-.45.725-.45 1.525ZM24 20.4q1.9 0 3.15-1.25T28.4 16q0-1.9-1.25-3.15T24 11.6q-1.9 0-3.15 1.25T19.6 16q0 1.9 1.25 3.15T24 20.4Zm0-4.4Zm0 21.05Z"/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="personal-account-input__container">
                <div class="dt-input__wrapper">
                    <div class="d-flex align-items-center justify-content-between"><label
                        class="dt-input__label">отчество</label>
                    </div>
                    <div class="dt-input__group bg-white">
                        <input type="text" placeholder="Петрович" class="dt-input"
                               autocomplete="off" maxlength="255">
                        <div class="dt-input__group-item">
                            <div class="dt-input__icon">
                                <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%"
                                     viewBox="0 0 48 48" fill="#0071eb">
                                    <path
                                        d="M24 23.8q-3.45 0-5.625-2.175T16.2 16q0-3.45 2.175-5.625T24 8.2q3.45 0 5.625 2.175T31.8 16q0 3.45-2.175 5.625T24 23.8ZM7.7 40.45v-5q0-2 1-3.425 1-1.425 2.55-2.175 3.4-1.5 6.5-2.25t6.25-.75q3.15 0 6.225.775Q33.3 28.4 36.7 29.9q1.6.7 2.6 2.125t1 3.425v5Zm3.4-3.4h25.8V35.5q0-.8-.475-1.525-.475-.725-1.175-1.075-3.15-1.5-5.775-2.075Q26.85 30.25 24 30.25q-2.85 0-5.525.575Q15.8 31.4 12.7 32.9q-.7.35-1.15 1.075-.45.725-.45 1.525ZM24 20.4q1.9 0 3.15-1.25T28.4 16q0-1.9-1.25-3.15T24 11.6q-1.9 0-3.15 1.25T19.6 16q0 1.9 1.25 3.15T24 20.4Zm0-4.4Zm0 21.05Z"/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="personal-account-input__row">
            <div class="personal-account-input__container personal-account-input-tel__container">
                <label class="personal-account-input__label">
                    телефон
                </label>
                <div class="dt-input__group personal-account-input__group personal-account-input-tel__group bg-white">
                    <input type="tel" name="name" class="dt-input tel" autocomplete="off"
                           placeholder="+7 (495) 400-56-66">
                    <div class="dt-input__group-item">
                        <div class="dt-input__icon">
                            <svg xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink" width="18" height="18"
                                 viewBox="0 0 18 18">
                                <image id="иконка" width="18" height="18"
                                       xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAABXklEQVQ4jaXUv0vWURTH8Vf6ZCCYoREtrSGKi0EgLkmTQlsUCEJDrpqDDmIGgUMN9R8EyiMkgQ4OQRAULQ1CqATl4CKKEPhjUFTQ5MKx5Is9PV/9TOfec77ve8+553su6P91DUO44q+WMIoDZaqAQfSdEr6It+WCKlAZ9lO0YzjWd8qFHINWwt7AJxRj3ZYXNJe5wSb20BT+skFfsI1O3MAHXMJXHOYB7eIdqvEdtwPSkTe1pNf4jRp8xF1snQU0j4mwV7GTByJTzAGsoxv3zwNaw+Owx3CrxHfVpUBJ03gege/RnPEXogTb0X+T6MHFSq2DWXhqyvro8i78xI/4A8ZjL9WwLnrtXnr5fzVcL56hFlNxcjEg6SYNuIqRiL9ZKFGHlOI3vMGD2EvTID3EcqwXTuZcSjNoxAs8ivQ+R/qzJ0dPmkf/Yf1RAj7BQ1zO+F7mAR2rCq1owXXs49UR9XpEY/iGbokAAAAASUVORK5CYII="/>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <button class="personal-account-input__link personal-account-input-tel__link dt-btn-text">
                сменить номер
            </button>
        </div>
        <div class="personal-account-input__row">
            <div class="personal-account-input__container personal-account-input-email__container">
                <div class="d-flex align-items-center justify-content-between"><label
                    class="dt-input__label">почта</label>
                </div>
                <div class="dt-input__wrapper">
                    <div class="dt-input__group bg-white">
                        <input type="text" placeholder="pochta123@gmail.com" class="dt-input"
                               autocomplete="off">
                        <div class="dt-input__group-item">
                            <div class="dt-input__icon">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                     xmlns:xlink="http://www.w3.org/1999/xlink" width="20" height="16"
                                     viewBox="0 0 20 16">
                                    <image id="mail_FILL0_wght600_GRAD0_opsz48" width="20" height="16"
                                           xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAQCAYAAAAWGF8bAAAA/UlEQVQ4jc3Su0pDQRDG8V/CAS+llZWdraSwUMRnsPYt4iVooyA2iqitvY2vIShYCEY7H0Gs7FIYlYUJrCHx6DmNH0wxO7P/ncs2bLw20cGyerrDSYF1HNWEJa3hJQHn4+AN27j/I2gRx5jBQpEFJnGBM+yjVwKaiLwdvMdZo5kltHGOLXSx9AMsxR6wG3fag0AO7MVyVsK/xSmms5ypNPiINSO3k3eTAwdK22pF6+nlR6yGPWEzYq3I/aZRwOFq+7gO64+qKlcxBjhc7WH4e2XLKgPm1f5K41qurP8PzGc4FwuoonQ36TMBn8M5CKujbgJeYTY+btURfOAGl184JDFFmd6fPgAAAABJRU5ErkJggg=="/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button class="personal-account-input-email__btn personal-account-input-email__btn_disabled">
                Подтвердить
            </button>
        </div>
        <div class="personal-account-input__row">
            <div class="personal-account-input__container personal-account-input-photo__container">
                <label class="personal-account-input__label">
                    добавьте фото
                </label>
                <div class="dt-input__group personal-account-input__group personal-account-input-photo__group">
                    <input type="file" name="name" class="dt-input personal-account-input-photo__input"
                           autocomplete="off"
                           placeholder="pochta123@gmail.com">
                    <div class="dt-input__group-item">
                        <div class="dt-input__icon">
                            <svg xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink" width="20" height="20"
                                 viewBox="0 0 20 20">
                                <image id="add_FILL0_wght600_GRAD0_opsz48" width="20" height="20"
                                       xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAAiklEQVQ4jWNkKHzNQACwMDAw8ECVfGVgYPiNTzkTIdMYGBhsGBgY3kOxNyHFxBhIEhg1cBAayALFNnjUGCCxdRgYGD7gUXsElLAFoGmMGkCQJl4GZadAPGpA3myGsjsYGBhO4lH7lQWaNzfgUYQcZicJqB3NKSPCQFCyIQSOgHIAVBEozeIGDAwMAJkKFMUQln3QAAAAAElFTkSuQmCC"/>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <button class="personal-account-input__btn personal-account-input-photo__btn fw-bold blue-underline">
                сменить фото
            </button>
            <button class="personal-account-input__btn personal-account-input-photo__btn fw-bold
                personal-account-input-photo__btn_red">
                удалить фото
            </button>
        </div>

        <div class="dt-check personal-account-check">
            <div class="dt-check__input">
                <input type="checkbox" name="hot_excursion">
                <div class="dt-check__input-check"></div>
            </div>
            <label class="dt-check__label">
                <slot name="label">
                    <h5>получать рекламные материалы по e-mail</h5>
                </slot>
            </label>
        </div>
        <div class="dt-check personal-account-check">
            <div class="dt-check__input">
                <input type="checkbox" name="hot_excursion">
                <div class="dt-check__input-check"></div>
            </div>
            <label class="dt-check__label">
                <slot name="label">
                    <h5>получать уведомления по СМС</h5>
                </slot>
            </label>
        </div>
        <button type="submit" class="dt-btn-blue personal-account__submit">
            <span>Сохранить</span>
        </button>
    </form>
</template>

<script>
export default {
    name: "UserSettings",
}
</script>

<style scoped>

</style>
