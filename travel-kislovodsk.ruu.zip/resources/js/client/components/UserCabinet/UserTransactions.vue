<template>
    <transaction-list/>
</template>

<script>
import TransactionList from "@/components/Transactions/TransactionList.vue";

export default {
    name: "Transactions",
    components: {TransactionList}
}
</script>

<style scoped>

</style>
