<template>
    <main class="dt-advantages">
        <div class="col-12 col-sm-12 align-self-center row mx-0 px-0 mt-5 d-flex justify-content-center">
            <h1 class="col-12 px-0 text-center bold fs-1">Преимущества нашего сервиса</h1>
            <span class="col-12 px-0 text-center thin font-size-09">вы оцените качество нашего сервиса по
                    достоинству</span>
            <div
                class="benefits row row-cols-1 row-cols-md-2 row-cols-lg-3 px-0 mx-0 mt-2rem rounded overflow-hidden d-flex justify-content-end">
                <div class="benefits__item col row mx-0 p-2rem">
                    <div class="col-1 px-0 big-icon">
                        <img v-lazy="'/img/icons/preferences/1.png'" alt="">
                    </div>
                    <div class="col d-flex flex-column px-0 ms-4 me-0">
                        <span class="bold font-size-09">Бесплатная отмена</span>
                        <span class="thin font-size-09 opacity-70 mt-1">Бесплатная отмена за 48 часов.</span>
                    </div>
                </div>
                <div class="benefits__item col row mx-0 p-2rem">
                    <div class="col-1 px-0 big-icon">
                        <img v-lazy="'/img/icons/preferences/2.png'" alt="">
                    </div>
                    <div class="col d-flex flex-column px-0 ms-4 me-0">
                        <span class="bold font-size-09">Мгновенное подтверждение</span>
                        <span class="thin font-size-09 opacity-70 mt-1">После оплаты вы получите билет на
                                электронную почту или телефон.</span>
                    </div>
                </div>
                <div class="benefits__item col row mx-0 p-2rem">
                    <div class="col-1 px-0 big-icon">
                        <img v-lazy="'/img/icons/preferences/3.png'" alt="">
                    </div>
                    <div class="col d-flex flex-column px-0 ms-4 me-0">
                        <span class="bold font-size-09">Оплата онлайн</span>
                        <span class="thin font-size-09 opacity-70 mt-1">Мы гарантируем сохранность платежей и
                                персональных данных.</span>
                    </div>
                </div>
                <div class="benefits__item col row mx-0 p-2rem">
                    <div class="col-1 px-0 big-icon">
                        <img v-lazy="'/img/icons/preferences/4.png'" alt="">
                    </div>
                    <div class="col d-flex flex-column px-0 ms-4 me-0">
                        <span class="bold font-size-09">Честные отзывы</span>
                        <span class="thin font-size-09 opacity-70 mt-1">15 000 отзывов наших клиентов, которым вы
                                можете доверять.</span>
                    </div>
                </div>
                <div class="benefits__item col row mx-0 p-2rem">
                    <div class="col-1 px-0 big-icon">
                        <img v-lazy="'/img/icons/preferences/5.png'" alt="">
                    </div>
                    <div class="col d-flex flex-column px-0 ms-4 me-0">
                        <span class="bold font-size-09">Лучшие экскурсии</span>
                        <span class="thin font-size-09 opacity-70 mt-1">Тщательно подобранные экскурсии со всего
                                мира на одном сайте.</span>
                    </div>
                </div>
                <div class="benefits__item col row mx-0 p-2rem">
                    <div class="col-1 px-0 big-icon">
                        <img v-lazy="'/img/icons/preferences/6.png'" alt="">
                    </div>
                    <div class="col d-flex flex-column px-0 ms-4 me-0">
                        <span class="bold font-size-09">Профессиональные гиды</span>
                        <span class="thin font-size-09 opacity-70 mt-1">15 000 отзывов наших клиентов, которым вы
                                можете доверять.</span>
                    </div>
                </div>
            </div>
        </div>
    </main>
</template>
