<template>
    <ul class="nav nav-pills dt-popular-list d-flex" id="pills-tab" role="tablist">
        <li class="nav-item flex-fill">
            <a class="nav-link" id="pills-1" data-toggle="pill" href="#pills-1" role="tab"
               aria-controls="pills-1" aria-selected="true">Все направления</a>
        </li>
        <li class="nav-item flex-fill">
            <a class="nav-link active" id="pills-2" data-toggle="pill" href="#pills-2" role="tab"
               aria-controls="pills-2" aria-selected="true">Северный Кавказ</a>
        </li>
        <li class="nav-item flex-fill">
            <a class="nav-link" id="pills-3" data-toggle="pill" href="#pills-3" role="tab"
               aria-controls="pills-3" aria-selected="true">Горы</a>
        </li>
        <li class="nav-item flex-fill">
            <a class="nav-link" id="pills-4" data-toggle="pill" href="#pills-4" role="tab"
               aria-controls="pills-4" aria-selected="true">Пешие прогулки</a>
        </li>
        <li class="nav-item flex-fill">
            <a class="nav-link" id="pills-5" data-toggle="pill" href="#pills-5" role="tab"
               aria-controls="pills-5" aria-selected="true">Экстрим</a>
        </li>
        <li class="nav-item flex-fill">
            <a class="nav-link" id="pills-6" data-toggle="pill" href="#pills-6" role="tab"
               aria-controls="pills-6" aria-selected="true">Романтическая экскурсия</a>
        </li>
        <li class="nav-item flex-fill">
            <a class="nav-link" id="pills-7" data-toggle="pill" href="#pills-7" role="tab"
               aria-controls="pills-7" aria-selected="true">Все направления</a>
        </li>
        <li class="nav-item flex-fill">
            <a class="nav-link" id="pills-8" data-toggle="pill" href="#pills-8" role="tab"
               aria-controls="pills-8" aria-selected="true">Северный Кавказ</a>
        </li>
    </ul>
</template>
