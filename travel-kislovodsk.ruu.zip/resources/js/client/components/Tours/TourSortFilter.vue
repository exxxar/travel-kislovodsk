<template>
    <div class="dt-sort">
        <div class="dt-sort-by d-lg-flex d-none">
            <p class="dt-sort-by__title">сортировка по</p>
            <p class="dt-sort-by__item active d-flex align-items-center">
                популярности
                <span class="dt-sort-by__icon">
                        <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%" viewBox="0 0 48 48">
                            <path d="m24 30-10-9.95h20Z"/>
                        </svg>
                        </span>
            </p>
            <p class="dt-sort-by__item d-flex align-items-center">
                кол-ву отзывов
                <span class="dt-sort-by__icon">
                        <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%" viewBox="0 0 48 48">
                            <path d="m24 30-10-9.95h20Z"/>
                        </svg>
                        </span>
            </p>
            <p class="dt-sort-by__item d-flex align-items-center">
                цене
                <span class="dt-sort-by__icon">
                        <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%" viewBox="0 0 48 48">
                            <path d="m24 30-10-9.95h20Z"/>
                        </svg>
                        </span>
            </p>
            <p class="dt-sort-by__item d-flex align-items-center">
                ближайшей дате
                <span class="dt-sort-by__icon">
                        <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%" viewBox="0 0 48 48">
                            <path d="m24 30-10-9.95h20Z"/>
                        </svg>
                        </span>
            </p>
            <p class="dt-sort-by__item d-flex align-items-center">
                скидке
                <span class="dt-sort-by__icon">
                        <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%" viewBox="0 0 48 48">
                            <path d="m24 30-10-9.95h20Z"/>
                        </svg>
                        </span>
            </p>
            <p class="dt-sort-by__item d-flex align-items-center">
                длительности
                <span class="dt-sort-by__icon">
                        <svg xmlns="http://www.w3.org/2000/svg" height="100%" width="100%" viewBox="0 0 48 48">
                            <path d="m24 30-10-9.95h20Z"/>
                        </svg>
                        </span>
            </p>
        </div>
        <div class="dt-sort-by d-lg-none d-flex justify-content-between">
            <p class="dt-sort-by__title">сортировка по</p>
            <p class="dt-sort-by__item active">популярности</p>
        </div>
    </div>
</template>
