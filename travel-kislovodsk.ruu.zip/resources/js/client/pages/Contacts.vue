<template>
    <main class="container">
        <div class="main row d-flex justify-content-center">
            <div class="row col-11 col-md-10 col-lg-8 align-self-center mx-0 px-0">
                <h3 class="col-12 px-0 mb-5 opacity-40 letter-spasing-3 text-uppercase">главная <span
                    class="fs-6 opacity-40">&gt;</span>
                    о проекте</h3>
                <h1 class="col-12 px-0 mb-4 bold fs-1">О проекте</h1>
                <p class="col-12 px-0 mb-5 thin font-size-09">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis ad exercitationem laborum
                    consequuntur blanditiis quae excepturi nisi voluptas ea quibusdam sunt ipsam amet dignissimos, quam
                    tempora dolor, soluta magni labore vitae dolores eius natus. Iure eos unde saepe dolores inventore,
                    blanditiis quasi culpa numquam, nesciunt laudantium natus alias sit voluptatem. Natus odit, facilis
                    quibusdam numquam autem vero alias minus libero ad magni nobis architecto recusandae commodi
                    suscipit exercitationem tenetur reprehenderit amet totam dolorum distinctio minima ullam veniam
                    saepe! At dolores voluptatem nam rem et ea dolore exercitationem temporibus soluta quisquam, ducimus
                    repudiandae! Optio dolor temporibus, consectetur eos exercitationem hic reiciendis!
                </p>

            </div>
            <div class="col-11 col-sm-12 align-self-center row mx-0 px-0 mt-5 d-flex justify-content-center">
                <benefits-component></benefits-component>
            </div>
        </div>
    </main>
</template>
