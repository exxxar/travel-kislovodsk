<template>
    <main class="container">
        <div class="main row d-flex justify-content-center">
            <div class="row col-11 col-md-10 col-lg-8 align-self-center mx-0 px-0">
                <h3 class="col-12 px-0 mb-5 opacity-40 letter-spasing-3 text-uppercase">главная <span
                    class="fs-6 opacity-40">&gt;</span>
                    о проекте</h3>
                <h1 class="col-12 px-0 mb-4 bold fs-1">О проекте</h1>


                <p class="col-12 px-0 mb-5 thin font-size-09">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis ad exercitationem laborum
                    consequuntur blanditiis quae excepturi nisi voluptas ea quibusdam sunt ipsam amet dignissimos, quam
                    tempora dolor, soluta magni labore vitae dolores eius natus. Iure eos unde saepe dolores inventore,
                    blanditiis quasi culpa numquam, nesciunt laudantium natus alias sit voluptatem. Natus odit, facilis
                    quibusdam numquam autem vero alias minus libero ad magni nobis architecto recusandae commodi
                    suscipit exercitationem tenetur reprehenderit amet totam dolorum distinctio minima ullam veniam
                    saepe! At dolores voluptatem nam rem et ea dolore exercitationem temporibus soluta quisquam, ducimus
                    repudiandae! Optio dolor temporibus, consectetur eos exercitationem hic reiciendis!
                </p>
                <h2 class="col-12 lh-1 mb-4 bold px-0">Некоторый подзаголовок</h2>
                <div class="col-12 px-0 mb-5">
                    <div class="row px-0 mx-0 mt-2">
                        <div
                            class="col-1 round-icon px-0 rounded bg-blue d-flex justify-content-center align-items-center">
                            <svg class="white" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 48 48" height="24"
                                 width="24">
                                <path d="M18.9 36.4 7 24.5l2.9-2.85 9 9L38.05 11.5l2.9 2.85Z" />
                            </svg>
                        </div>
                        <span class="col thin font-size-09 mt-2">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            Quasi, explicabo!</span>
                    </div>
                    <div class="row px-0 mx-0 mt-2">
                        <div
                            class="col-1 round-icon px-0 rounded bg-blue d-flex justify-content-center align-items-center">
                            <svg class="white" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 48 48" height="24"
                                 width="24">
                                <path d="M18.9 36.4 7 24.5l2.9-2.85 9 9L38.05 11.5l2.9 2.85Z" />
                            </svg>
                        </div>
                        <span class="col thin font-size-09 mt-2">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            Quasi, explicabo!</span>
                    </div>
                    <div class="row px-0 mx-0 mt-2">
                        <div
                            class="col-1 round-icon px-0 rounded bg-blue d-flex justify-content-center align-items-center">
                            <svg class="white" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 48 48" height="24"
                                 width="24">
                                <path d="M18.9 36.4 7 24.5l2.9-2.85 9 9L38.05 11.5l2.9 2.85Z" />
                            </svg>
                        </div>
                        <span class="col thin font-size-09 mt-2">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            Quasi, explicabo!</span>
                    </div>
                    <div class="row px-0 mx-0 mt-2">
                        <div
                            class="col-1 round-icon px-0 rounded bg-blue d-flex justify-content-center align-items-center">
                            <svg class="white" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 48 48" height="24"
                                 width="24">
                                <path d="M18.9 36.4 7 24.5l2.9-2.85 9 9L38.05 11.5l2.9 2.85Z" />
                            </svg>
                        </div>
                        <span class="col thin font-size-09 mt-2">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            Quasi, explicabo!</span>
                    </div>
                </div>
                <h2 class="col-12 lh-1 mb-4 bold px-0">Рыбный текст</h2>
                <p class="col-12 px-0 mb-5 thin font-size-09">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis ad exercitationem laborum
                    consequuntur blanditiis quae excepturi nisi voluptas ea quibusdam sunt ipsam amet dignissimos, quam
                    tempora dolor, soluta magni labore vitae dolores eius natus. Iure eos unde saepe dolores inventore,
                    blanditiis quasi culpa numquam, nesciunt laudantium natus alias sit voluptatem. Natus odit, facilis
                    quibusdam numquam autem vero alias minus libero ad magni nobis architecto recusandae commodi
                    suscipit exercitationem tenetur reprehenderit amet totam dolorum distinctio minima ullam veniam
                    saepe! At dolores voluptatem nam rem et ea dolore exercitationem temporibus soluta quisquam, ducimus
                    repudiandae! Optio dolor temporibus, consectetur eos exercitationem hic reiciendis!
                </p>
                <div class="slider rounded col-12 px-0 mb-5">
                    <div class="slider__list">
                        <div class="slider__track">
                            <div class="slider__slide">
                                <img v-lazy="'/img/4.jpg'" alt="">
                            </div>
                            <div class="slider__slide">
                                <img v-lazy="" alt="">
                            </div>
                            <div class="slider__slide">
                                <img v-lazy="" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="slider__arrows">
                        <button type="button" class="slider__prev rounded big-icon bg-blue fs-4">&lt;</button>
                        <button type="button" class="slider__next rounded big-icon bg-blue fs-4">&gt;</button>
                    </div>
                </div>
                <p class="col-12 px-0 mb-5 thin font-size-09">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis ad exercitationem laborum
                    consequuntur blanditiis quae excepturi nisi voluptas ea quibusdam sunt ipsam amet dignissimos, quam
                    tempora dolor, soluta magni labore vitae dolores eius natus. Iure eos unde saepe dolores inventore,
                    blanditiis quasi culpa numquam, nesciunt laudantium natus alias sit voluptatem. Natus odit, facilis
                    quibusdam numquam autem vero alias minus libero ad magni nobis architecto recusandae commodi
                    suscipit exercitationem tenetur reprehenderit amet totam dolorum distinctio minima ullam veniam
                    saepe! At dolores voluptatem nam rem et ea dolore exercitationem temporibus soluta quisquam, ducimus
                    repudiandae! Optio dolor temporibus, consectetur eos exercitationem hic reiciendis!
                </p>
                <div class="col-12 mb-5 px-0">
                    <a class="position-relative blue blue-underline font-size-09" href="">Ссылка</a>
                    <a class="position-relative blue blue-underline font-size-09 ms-4" href="">Еще ссылка куда-то</a>
                </div>
                <h2 class="col-12 lh-1 mb-4 bold px-0">Подзаголовок</h2>
                <p class="col-12 px-0 mb-5 thin font-size-09">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis ad exercitationem laborum
                    consequuntur blanditiis quae excepturi nisi voluptas ea quibusdam sunt ipsam amet dignissimos, quam
                    tempora dolor, soluta magni labore vitae dolores eius natus. Iure eos unde saepe dolores inventore,
                    blanditiis quasi culpa numquam, nesciunt laudantium natus alias sit voluptatem. Natus odit, facilis
                    quibusdam numquam autem vero alias minus libero ad magni nobis architecto recusandae commodi
                    suscipit exercitationem tenetur reprehenderit amet totam dolorum distinctio minima ullam veniam
                    saepe! At dolores voluptatem nam rem et ea dolore exercitationem temporibus soluta quisquam, ducimus
                    repudiandae! Optio dolor temporibus, consectetur eos exercitationem hic reiciendis!
                </p>
                <div class="col-12 bg-image p-3 rounded">
                    <div
                        class="row col-12 px-5 py-2rem mx-0 bg-light d-flex justify-content-between align-items-center">
                        <div class="col-12 col-lg-6 row px-0 mx-0">
                            <span class="col-12 px-0 bold fs-5">Остались вопросы?</span>
                            <span class="col-12 px-0 mt-2 thin font-size-09">Вы можете пообщаться, задать их через
                                специальную
                                форму, и мы обязательно ответим на любой ваш вопрос.</span>
                        </div>
                        <button class="big-button rounded col-12 col-lg-auto px-5 mt-3 mt-lg-0 bg-blue bold font-size-09">Задать вопрос</button>
                    </div>
                </div>
            </div>
        </div>
    </main>
</template>
