<template>
    favorites
</template>
