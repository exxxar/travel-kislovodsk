<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.content')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/bookings')); ?>"><i class="nav-icon icon-book-open"></i> <?php echo e(trans('admin.booking.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/companies')); ?>"><i class="nav-icon icon-star"></i> <?php echo e(trans('admin.company.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/dictionaries')); ?>"><i class="nav-icon icon-flag"></i> <?php echo e(trans('admin.dictionary.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/dictionary-types')); ?>"><i class="nav-icon icon-puzzle"></i> <?php echo e(trans('admin.dictionary-type.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/documents')); ?>"><i class="nav-icon icon-book-open"></i> <?php echo e(trans('admin.document.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/favorites')); ?>"><i class="nav-icon icon-compass"></i> <?php echo e(trans('admin.favorite.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/messages')); ?>"><i class="nav-icon icon-energy"></i> <?php echo e(trans('admin.message.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/profiles')); ?>"><i class="nav-icon icon-globe"></i> <?php echo e(trans('admin.profile.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/reviews')); ?>"><i class="nav-icon icon-book-open"></i> <?php echo e(trans('admin.review.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/schedules')); ?>"><i class="nav-icon icon-ghost"></i> <?php echo e(trans('admin.schedule.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/tours')); ?>"><i class="nav-icon icon-star"></i> <?php echo e(trans('admin.tour.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/tourist-agencies')); ?>"><i class="nav-icon icon-compass"></i> <?php echo e(trans('admin.tourist-agency.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/tourist-groups')); ?>"><i class="nav-icon icon-book-open"></i> <?php echo e(trans('admin.tourist-group.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/tourist-guides')); ?>"><i class="nav-icon icon-globe"></i> <?php echo e(trans('admin.tourist-guide.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/tourist-members')); ?>"><i class="nav-icon icon-puzzle"></i> <?php echo e(trans('admin.tourist-member.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/tour-objects')); ?>"><i class="nav-icon icon-flag"></i> <?php echo e(trans('admin.tour-object.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/transactions')); ?>"><i class="nav-icon icon-puzzle"></i> <?php echo e(trans('admin.transaction.title')); ?></a></li>
           

            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.settings')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/admin-users')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage access')); ?></a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/translations')); ?>"><i class="nav-icon icon-location-pin"></i> <?php echo e(__('Translations')); ?></a></li>
            
            
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
<?php /**PATH D:\OpenServer\domains\travel-kislovodsk.ruu\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>