<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <?php if(Auth::check()): ?>
        <meta name="user" content="<?php echo e(\App\Models\User::self()); ?>"/>
    <?php endif; ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>

    <link rel="stylesheet" href="/css/main.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
</head>
<body>
<div id="app">
    <?php echo $__env->yieldContent("content"); ?>
</div>

<?php echo app('Illuminate\Foundation\Vite')(['resources/js/client/app.js']); ?>
</body>
</html>
<?php /**PATH D:\OpenServer\domains\travel-kislovodsk.ruu\resources\views/layouts/app.blade.php ENDPATH**/ ?>