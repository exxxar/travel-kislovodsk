<?php $__env->startSection("content"); ?>
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component class="position-absolute dt-page-header--bg-none-image"></header-component>
    <tour-page :tour="<?php echo e($tour); ?>"></tour-page>
    <footer-component></footer-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\travel-kislovodsk.ruu\resources\views/pages/tour.blade.php ENDPATH**/ ?>