<?php $__env->startSection("content"); ?>
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component class="position-absolute dt-page-header--bg-none-image"></header-component>
    <main-page></main-page>
    <footer-component></footer-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\travel-kislovodsk\resources\views/pages/main.blade.php ENDPATH**/ ?>