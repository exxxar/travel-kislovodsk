<?php echo e($name); ?>

<?php echo e($email); ?>

<?php echo e($phone); ?>

<p>Регистрация успешна! Тестовый шаблон</p>
<?php /**PATH D:\OpenServer\domains\travel-kislovodsk.ruu\resources\views/emails/registration.blade.php ENDPATH**/ ?>