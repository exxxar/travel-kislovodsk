

<?php $__env->startSection("content"); ?>
    <modals-component></modals-component>
    <notifications-component></notifications-component>
    <header-component></header-component>
    <tours-all-page></tours-all-page>
    <benefits-component></benefits-component>
    <footer-component></footer-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\travel-kislovodsk.ruu\resources\views/pages/tours-all.blade.php ENDPATH**/ ?>